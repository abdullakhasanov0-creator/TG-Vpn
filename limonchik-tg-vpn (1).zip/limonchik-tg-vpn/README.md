# TG VPN — лёгкий клиент Telegram со встроенным VPN

**Автор: limonchik**

Вставляешь ключ (`vless://`, `vmess://`, `trojan://`, `ss://`) — и Telegram работает через встроенный VPN-прокси. Ничего больше настраивать не надо.

Два приложения на общем ядре (Kotlin, Jetpack Compose):

| Модуль | Для чего |
|---|---|
| `app-phone` | телефон |
| `app-watch` | квадратные часы (Wear OS и обычные Android-часы): компактный UI, быстрые ответы |
| `core` | разбор ключа → конфиг Xray, TDLib-клиент, общий ViewModel |

## Как это устроено
- **VPN:** ядро Xray (`libv2ray.aar`) поднимает локальный SOCKS5 на `127.0.0.1` с случайным логином/паролем.
- **Telegram:** TDLib (официальная библиотека) настроен на этот прокси — весь трафик Telegram идёт через ключ. Системный VpnService не нужен, поэтому работает и на часах.
- **Лёгкость:** без базы сообщений и файлов, только arm64-v8a/armeabi-v7a, R8-минификация.

## Сборка
1. TDLib подтягивается сам (JitPack). Положите в `libs/` только `libv2ray.aar` (релизы 2dust/AndroidLibXrayLite).
2. Получите `api_id` / `api_hash` на https://my.telegram.org и пропишите в `local.properties` (пример — `local.properties.example`).
3. `gradle wrapper` (один раз), затем:
   ```
   ./gradlew :app-phone:assembleRelease
   ./gradlew :app-watch:assembleRelease
   ```
4. Подпишите APK своим ключом.

Ключ можно передать и ссылкой/«Поделиться» — приложение откроется и подключится само (удобно для часов: `adb shell am start -a android.intent.action.VIEW -d "vless://..." dev.limonchik.tgvpn.watch`).

## Статус
Первая версия (MVP): вход по номеру, список чатов, чтение и отправка текста. Пока нет: фоновой работы/уведомлений (нужен foreground-сервис), медиа, иконки приложения, VPN на всё устройство.

## Лицензии
Код проекта — MIT (© limonchik). Используются TDLib (Boost 1.0) и Xray-core (MPL-2.0) — соблюдайте их условия и [Telegram API Terms](https://core.telegram.org/api/terms).

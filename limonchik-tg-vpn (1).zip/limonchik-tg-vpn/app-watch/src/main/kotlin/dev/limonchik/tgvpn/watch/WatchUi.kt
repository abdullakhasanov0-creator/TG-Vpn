package dev.limonchik.tgvpn.watch

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.limonchik.tgvpn.core.*

/**
 * UI для КВАДРАТНЫХ часов (Wear OS и обычный Android): без круглых вырезов,
 * мелкие отступы и шрифты, большие кнопки, быстрые ответы вместо клавиатуры.
 */
@Composable
fun WatchApp(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            when (val s = ui.screen) {
                Screen.Key -> KeyScreen(ui, vm)
                Screen.Auth -> AuthScreen(ui, vm)
                Screen.Chats -> ChatsScreen(ui, vm)
                is Screen.Chat -> ChatScreen(s.item, ui, vm)
            }
        }
    }
}

private val small = 12.sp
private val Pad = 6.dp

@Composable
private fun Err(e: String?) {
    if (e != null) Text(e, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
}

@Composable
private fun WBtn(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 40.dp), contentPadding = PaddingValues(4.dp)) {
        Text(label, fontSize = small)
    }
}

@Composable
private fun KeyScreen(ui: UiState, vm: MainViewModel) {
    var key by remember { mutableStateOf(ui.savedKey) }
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Pad), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Ключ VPN", fontSize = 14.sp)
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 11.sp), maxLines = 3, placeholder = { Text("vless://…", fontSize = 11.sp) })
        WBtn("Вставить из буфера") { clip.getText()?.text?.let { key = it } }
        WBtn(if (ui.busy) "Подключение…" else "Подключить", enabled = key.isNotBlank() && !ui.busy) { vm.connect(key) }
        Err(ui.error)
        Text("Автор: $AUTHOR", fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun AuthScreen(ui: UiState, vm: MainViewModel) {
    var v by remember(ui.auth) { mutableStateOf("") }
    val (label, kb) = when (ui.auth) {
        AuthStep.Phone -> "Телефон +7…" to KeyboardType.Phone
        AuthStep.Code -> "Код из Telegram" to KeyboardType.Number
        AuthStep.Password -> "Пароль 2FA" to KeyboardType.Password
        else -> "" to KeyboardType.Text
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Pad), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (label.isEmpty()) {
            Text("VPN запущен, соединяюсь…", fontSize = small)
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else {
            OutlinedTextField(v, { v = it }, Modifier.fillMaxWidth(), label = { Text(label, fontSize = 11.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = kb), textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
            WBtn("Далее", enabled = v.isNotBlank()) {
                when (ui.auth) {
                    AuthStep.Phone -> vm.submitPhone(v)
                    AuthStep.Code -> vm.submitCode(v)
                    else -> vm.submitPassword(v)
                }
            }
        }
        Err(ui.error)
        TextButton(onClick = vm::disconnect) { Text("Сменить ключ", fontSize = 11.sp) }
    }
}

@Composable
private fun ChatsScreen(ui: UiState, vm: MainViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(Pad)) {
        item { Err(ui.error) }
        items(ui.chats, key = { it.id }) { c ->
            Column(Modifier.fillMaxWidth().clickable { vm.openChat(c) }.padding(vertical = 5.dp)) {
                Text(c.title, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(c.last, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HorizontalDivider()
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = vm::refreshChats) { Text("Обновить", fontSize = 11.sp) }
                TextButton(onClick = vm::disconnect) { Text("Выйти", fontSize = 11.sp) }
            }
        }
    }
}

private val quick = listOf("👍", "Ок", "Позже", "Да", "Нет")

@Composable
private fun ChatScreen(chat: ChatItem, ui: UiState, vm: MainViewModel) {
    BackHandler { vm.back() }
    var text by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(ui.messages.size) { if (ui.messages.isNotEmpty()) list.animateScrollToItem(ui.messages.size - 1) }
    Column(Modifier.fillMaxSize().imePadding()) {
        Text(chat.title, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().clickable { vm.back() }.padding(horizontal = Pad, vertical = 4.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(horizontal = Pad), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            items(ui.messages, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.out) Arrangement.End else Arrangement.Start) {
                    Surface(shape = RoundedCornerShape(8.dp),
                        color = if (m.out) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        Text(m.text, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                    }
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = Pad), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            quick.forEach { q -> AssistChip(onClick = { vm.send(q) }, label = { Text(q, fontSize = 11.sp) }) }
        }
        Row(Modifier.padding(Pad), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, textStyle = LocalTextStyle.current.copy(fontSize = 12.sp))
            Button(onClick = { vm.send(text); text = "" }, enabled = text.isNotBlank(), contentPadding = PaddingValues(6.dp)) { Text("➤", fontSize = small) }
        }
    }
}

package dev.limonchik.tgvpn.phone

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.limonchik.tgvpn.core.*

@Composable
fun PhoneApp(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            when (val s = ui.screen) {
                Screen.Key -> KeyScreen(ui, vm)
                Screen.Auth -> AuthScreen(ui, vm)
                Screen.Chats -> ChatsScreen(ui, vm)
                is Screen.Chat -> ChatScreen(s.item, ui, vm)
            }
        }
    }
}

@Composable
private fun ErrorText(e: String?) {
    if (e != null) Text(e, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun KeyScreen(ui: UiState, vm: MainViewModel) {
    var key by remember { mutableStateOf(ui.savedKey) }
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Вставьте ключ", style = MaterialTheme.typography.headlineSmall)
        Text("vless:// · vmess:// · trojan:// · ss://", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            value = key, onValueChange = { key = it }, label = { Text("Ключ") },
            modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { clip.getText()?.text?.let { key = it } }) { Text("Вставить") }
            Button(onClick = { vm.connect(key) }, enabled = key.isNotBlank() && !ui.busy) {
                Text(if (ui.busy) "Подключение…" else "Подключить")
            }
        }
        ErrorText(ui.error)
        Spacer(Modifier.weight(1f))
        Text("Автор: $AUTHOR", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun AuthScreen(ui: UiState, vm: MainViewModel) {
    var v by remember(ui.auth) { mutableStateOf("") }
    val (label, kb) = when (ui.auth) {
        AuthStep.Phone -> "Номер телефона (+7…)" to KeyboardType.Phone
        AuthStep.Code -> "Код из Telegram" to KeyboardType.Number
        AuthStep.Password -> "Пароль 2FA" to KeyboardType.Password
        else -> "" to KeyboardType.Text
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Вход в Telegram", style = MaterialTheme.typography.headlineSmall)
        if (label.isEmpty()) {
            Text("VPN запущен, соединяюсь…")
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else {
            OutlinedTextField(
                value = v, onValueChange = { v = it }, label = { Text(label) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = kb),
                visualTransformation = if (ui.auth == AuthStep.Password) PasswordVisualTransformation() else VisualTransformation.None,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = {
                when (ui.auth) {
                    AuthStep.Phone -> vm.submitPhone(v)
                    AuthStep.Code -> vm.submitCode(v)
                    else -> vm.submitPassword(v)
                }
            }, enabled = v.isNotBlank()) { Text("Далее") }
        }
        ErrorText(ui.error)
        TextButton(onClick = vm::disconnect) { Text("Сменить ключ") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatsScreen(ui: UiState, vm: MainViewModel) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("Чаты") }, actions = {
            TextButton(onClick = vm::refreshChats) { Text("Обновить") }
            TextButton(onClick = vm::disconnect) { Text("Выйти") }
        })
    }) { pad ->
        Column(Modifier.padding(pad)) {
            ErrorText(ui.error)
            LazyColumn(Modifier.fillMaxSize()) {
                items(ui.chats, key = { it.id }) { c ->
                    ListItem(
                        headlineContent = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(c.last, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        modifier = Modifier.clickable { vm.openChat(c) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(chat: ChatItem, ui: UiState, vm: MainViewModel) {
    BackHandler { vm.back() }
    var text by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(ui.messages.size) { if (ui.messages.isNotEmpty()) list.animateScrollToItem(ui.messages.size - 1) }
    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(title = { Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { TextButton(onClick = vm::back) { Text("←") } })
        },
        bottomBar = {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Сообщение") }, maxLines = 4)
                Button(onClick = { vm.send(text); text = "" }, enabled = text.isNotBlank()) { Text("➤") }
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), state = list, contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(ui.messages, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.out) Arrangement.End else Arrangement.Start) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (m.out) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    ) { Text(m.text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) }
                }
            }
        }
    }
}

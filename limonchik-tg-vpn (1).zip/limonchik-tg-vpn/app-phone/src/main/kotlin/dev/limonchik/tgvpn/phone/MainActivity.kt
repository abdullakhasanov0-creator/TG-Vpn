package dev.limonchik.tgvpn.phone

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import dev.limonchik.tgvpn.core.KeyParser
import dev.limonchik.tgvpn.core.MainViewModel
import dev.limonchik.tgvpn.core.TgConfig

/** Автор: limonchik */
class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TgConfig.apiId = BuildConfig.TG_API_ID
        TgConfig.apiHash = BuildConfig.TG_API_HASH
        if (savedInstanceState == null) handleIntent(intent)
        setContent { PhoneApp(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val key = i?.data?.toString() ?: i?.getStringExtra(Intent.EXTRA_TEXT)
        if (key != null && KeyParser.looksLikeKey(key)) vm.connect(key)
    }
}

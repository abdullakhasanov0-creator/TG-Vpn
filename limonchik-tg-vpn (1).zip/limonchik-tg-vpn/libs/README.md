Сюда кладётся `libv2ray.aar` — ядро Xray для Android:
https://github.com/2dust/AndroidLibXrayLite/releases
(в git не коммитится; в GitHub Actions скачивается автоматически).
TDLib подключается автоматически через JitPack.

package dev.limonchik.tgvpn.core

import android.net.Uri
import android.util.Base64
import kotlinx.serialization.json.*
import java.security.SecureRandom

/** Готовый конфиг Xray + данные локального SOCKS5, через который ходит Telegram. */
class ProxyConfig(val json: String, val socksPort: Int, val user: String, val pass: String)

/** Превращает ключ (vless/vmess/trojan/ss) в конфиг Xray с локальным SOCKS5-входом на 127.0.0.1. */
object KeyParser {
    private val prefixes = listOf("vless://", "vmess://", "trojan://", "ss://")

    fun looksLikeKey(s: String) = prefixes.any { s.trim().startsWith(it) }

    fun parse(rawKey: String, socksPort: Int = 10808): ProxyConfig {
        val key = rawKey.trim()
        val outbound = when {
            key.startsWith("vless://") -> vless(key)
            key.startsWith("trojan://") -> trojan(key)
            key.startsWith("vmess://") -> vmess(key)
            key.startsWith("ss://") -> shadowsocks(key)
            else -> throw IllegalArgumentException("Нужен ключ vless://, vmess://, trojan:// или ss://")
        }
        val user = token(8)
        val pass = token(16)
        val cfg = buildJsonObject {
            putJsonObject("log") { put("loglevel", "warning") }
            putJsonArray("inbounds") {
                addJsonObject {
                    put("tag", "socks-in")
                    put("listen", "127.0.0.1")
                    put("port", socksPort)
                    put("protocol", "socks")
                    putJsonObject("settings") {
                        put("auth", "password")
                        putJsonArray("accounts") { addJsonObject { put("user", user); put("pass", pass) } }
                        put("udp", true)
                    }
                }
            }
            putJsonArray("outbounds") {
                add(outbound)
                addJsonObject { put("tag", "direct"); put("protocol", "freedom") }
            }
        }
        return ProxyConfig(cfg.toString(), socksPort, user, pass)
    }

    private fun vless(key: String): JsonObject {
        val u = Uri.parse(key)
        val q = { n: String -> u.getQueryParameter(n) }
        return buildJsonObject {
            put("tag", "proxy"); put("protocol", "vless")
            putJsonObject("settings") {
                putJsonArray("vnext") {
                    addJsonObject {
                        put("address", u.host ?: error("В ключе нет адреса сервера"))
                        put("port", if (u.port > 0) u.port else 443)
                        putJsonArray("users") {
                            addJsonObject {
                                put("id", u.userInfo ?: error("В ключе нет UUID"))
                                put("encryption", q("encryption") ?: "none")
                                q("flow")?.takeIf { it.isNotEmpty() }?.let { put("flow", it) }
                            }
                        }
                    }
                }
            }
            put("streamSettings", stream(q))
        }
    }

    private fun trojan(key: String): JsonObject {
        val u = Uri.parse(key)
        val q = { n: String -> u.getQueryParameter(n) }
        return buildJsonObject {
            put("tag", "proxy"); put("protocol", "trojan")
            putJsonObject("settings") {
                putJsonArray("servers") {
                    addJsonObject {
                        put("address", u.host ?: error("В ключе нет адреса сервера"))
                        put("port", if (u.port > 0) u.port else 443)
                        put("password", u.userInfo ?: error("В ключе нет пароля"))
                    }
                }
            }
            put("streamSettings", stream { n -> if (n == "security") (q(n) ?: "tls") else q(n) })
        }
    }

    private fun vmess(key: String): JsonObject {
        val j = Json.parseToJsonElement(b64(key.removePrefix("vmess://").trim())).jsonObject
        fun s(n: String) = j[n]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotEmpty() }
        val map = mapOf(
            "type" to s("net"), "security" to if (s("tls") == "tls") "tls" else "none",
            "path" to s("path"), "host" to s("host"), "sni" to s("sni"), "fp" to s("fp"),
            "alpn" to s("alpn"), "serviceName" to s("path"),
        )
        return buildJsonObject {
            put("tag", "proxy"); put("protocol", "vmess")
            putJsonObject("settings") {
                putJsonArray("vnext") {
                    addJsonObject {
                        put("address", s("add") ?: error("В ключе нет адреса сервера"))
                        put("port", s("port")?.toInt() ?: 443)
                        putJsonArray("users") {
                            addJsonObject {
                                put("id", s("id") ?: error("В ключе нет UUID"))
                                put("alterId", s("aid")?.toInt() ?: 0)
                                put("security", s("scy") ?: "auto")
                            }
                        }
                    }
                }
            }
            put("streamSettings", stream { map[it] })
        }
    }

    private fun shadowsocks(key: String): JsonObject {
        val body = key.removePrefix("ss://").substringBefore('#')
        val (userInfo, hostPort) = if ('@' in body) {
            body.substringBeforeLast('@') to body.substringAfterLast('@')
        } else {
            val d = b64(body); d.substringBeforeLast('@') to d.substringAfterLast('@')
        }
        val ui = if (':' in userInfo) Uri.decode(userInfo) else b64(userInfo)
        val host = hostPort.substringBeforeLast(':')
        val port = hostPort.substringAfterLast(':').substringBefore('/').substringBefore('?').toInt()
        return buildJsonObject {
            put("tag", "proxy"); put("protocol", "shadowsocks")
            putJsonObject("settings") {
                putJsonArray("servers") {
                    addJsonObject {
                        put("address", host); put("port", port)
                        put("method", ui.substringBefore(':')); put("password", ui.substringAfter(':'))
                    }
                }
            }
        }
    }

    private fun stream(q: (String) -> String?): JsonObject {
        val net = q("type") ?: "tcp"
        val sec = q("security") ?: "none"
        return buildJsonObject {
            put("network", net)
            put("security", sec)
            when (net) {
                "ws" -> putJsonObject("wsSettings") {
                    put("path", q("path") ?: "/")
                    q("host")?.let { putJsonObject("headers") { put("Host", it) } }
                }
                "grpc" -> putJsonObject("grpcSettings") { put("serviceName", q("serviceName") ?: "") }
            }
            if (sec == "tls") putJsonObject("tlsSettings") {
                put("serverName", q("sni") ?: q("host") ?: "")
                put("fingerprint", q("fp") ?: "chrome")
                q("alpn")?.let { a -> putJsonArray("alpn") { a.split(",").forEach { add(it) } } }
            }
            if (sec == "reality") putJsonObject("realitySettings") {
                put("serverName", q("sni") ?: "")
                put("fingerprint", q("fp") ?: "chrome")
                put("publicKey", q("pbk") ?: "")
                put("shortId", q("sid") ?: "")
                put("spiderX", q("spx") ?: "")
            }
        }
    }

    private fun b64(s: String): String {
        var t = s.replace('-', '+').replace('_', '/')
        while (t.length % 4 != 0) t += "="
        return String(Base64.decode(t, Base64.DEFAULT))
    }

    private fun token(n: Int): String {
        val b = ByteArray(n).also { SecureRandom().nextBytes(it) }
        return b.joinToString("") { "%02x".format(it) }
    }
}

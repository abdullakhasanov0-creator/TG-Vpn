package dev.limonchik.tgvpn.core

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Key : Screen
    data object Auth : Screen
    data object Chats : Screen
    data class Chat(val item: ChatItem) : Screen
}

data class UiState(
    val screen: Screen = Screen.Key,
    val auth: AuthStep = AuthStep.Starting,
    val savedKey: String = "",
    val busy: Boolean = false,
    val error: String? = null,
    val chats: List<ChatItem> = emptyList(),
    val messages: List<MsgItem> = emptyList(),
)

/** Общая логика для телефона и часов: ключ -> VPN -> вход в Telegram -> чаты. */
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tgvpn", Context.MODE_PRIVATE)
    private val engine = XrayEngine(app)
    private var tg: TgClient? = null
    private var connectJob: Job? = null
    private var tgJob: Job? = null

    private val _ui = MutableStateFlow(UiState(savedKey = prefs.getString("key", "") ?: ""))
    val ui = _ui.asStateFlow()

    init {
        if (_ui.value.savedKey.isNotBlank()) connect(_ui.value.savedKey)
    }

    fun connect(raw: String) {
        connectJob?.cancel()
        connectJob = viewModelScope.launch {
            _ui.update { it.copy(busy = true, error = null) }
            try {
                val cfg = KeyParser.parse(raw)
                withContext(Dispatchers.IO) { engine.stop(); engine.start(cfg.json) }
                prefs.edit().putString("key", raw.trim()).apply()
                tgJob?.cancel()
                tg?.close()
                val c = TgClient(getApplication(), cfg)
                tg = c
                _ui.update { it.copy(savedKey = raw.trim(), screen = Screen.Auth, auth = AuthStep.Starting, busy = false) }
                tgJob = launch {
                    launch { c.auth.collect { onAuth(it) } }
                    launch { c.errors.collect { e -> _ui.update { it.copy(error = e) } } }
                    launch { c.events.collect { onEvent(it) } }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(busy = false, error = e.message ?: "Ошибка подключения", screen = Screen.Key) }
            }
        }
    }

    private fun onAuth(a: AuthStep) {
        _ui.update { s ->
            s.copy(
                auth = a,
                screen = when (a) {
                    AuthStep.Ready -> if (s.screen is Screen.Chats || s.screen is Screen.Chat) s.screen else Screen.Chats
                    AuthStep.Closed -> Screen.Key
                    else -> Screen.Auth
                },
            )
        }
        if (a == AuthStep.Ready) refreshChats()
    }

    private fun onEvent(e: TgEvent) = _ui.update { s ->
        val open = (s.screen as? Screen.Chat)?.item?.id
        when (e) {
            is TgEvent.NewMessage -> {
                val (hit, rest) = s.chats.partition { it.id == e.chatId }
                s.copy(
                    messages = if (open == e.chatId) s.messages + e.msg else s.messages,
                    chats = hit.map { it.copy(last = e.msg.text) } + rest,
                )
            }
            is TgEvent.Replaced ->
                if (open == e.chatId) s.copy(messages = s.messages.map { if (it.id == e.oldId) e.msg else it }) else s
        }
    }

    fun submitPhone(v: String) = tg?.sendPhone(v.trim())
    fun submitCode(v: String) = tg?.sendCode(v.trim())
    fun submitPassword(v: String) = tg?.sendPassword(v)
    fun clearError() = _ui.update { it.copy(error = null) }

    fun refreshChats() {
        viewModelScope.launch {
            try {
                val l = tg?.loadChats() ?: return@launch
                _ui.update { it.copy(chats = l) }
            } catch (e: Exception) {
                _ui.update { it.copy(error = e.message) }
            }
        }
    }

    fun openChat(c: ChatItem) {
        _ui.update { it.copy(screen = Screen.Chat(c), messages = emptyList()) }
        viewModelScope.launch {
            try {
                val m = tg?.history(c.id) ?: return@launch
                _ui.update { it.copy(messages = m) }
            } catch (e: Exception) {
                _ui.update { it.copy(error = e.message) }
            }
        }
    }

    fun back() = _ui.update { it.copy(screen = Screen.Chats) }

    fun send(text: String) {
        val s = _ui.value.screen as? Screen.Chat ?: return
        if (text.isNotBlank()) tg?.send(s.item.id, text.trim())
    }

    /** Выключить VPN и забыть ключ. */
    fun disconnect() {
        connectJob?.cancel(); tgJob?.cancel()
        tg?.close(); tg = null
        engine.stop()
        prefs.edit().remove("key").apply()
        _ui.value = UiState()
    }

    override fun onCleared() {
        engine.stop()
    }
}

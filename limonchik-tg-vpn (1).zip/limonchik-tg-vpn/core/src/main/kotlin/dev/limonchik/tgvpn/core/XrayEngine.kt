package dev.limonchik.tgvpn.core

import android.content.Context
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

/**
 * Обёртка над libv2ray.aar (Xray, gomobile).
 * Поднимает локальный SOCKS5 на 127.0.0.1 — Telegram (TDLib) ходит только через него.
 * Если в вашей версии AAR другие сигнатуры (newCoreController / startLoop) — поправьте здесь, остальной код не затрагивается.
 */
class XrayEngine(private val ctx: Context) {
    private var controller: CoreController? = null

    private val handler = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(l: Long, s: String?): Long = 0
    }

    @Synchronized
    fun start(configJson: String) {
        Libv2ray.initCoreEnv(ctx.filesDir.absolutePath, "")
        val c = Libv2ray.newCoreController(handler)
        c.startLoop(configJson, 0)
        controller = c
    }

    @Synchronized
    fun stop() {
        runCatching { controller?.stopLoop() }
        controller = null
    }

    val running: Boolean get() = controller?.isRunning == true
}

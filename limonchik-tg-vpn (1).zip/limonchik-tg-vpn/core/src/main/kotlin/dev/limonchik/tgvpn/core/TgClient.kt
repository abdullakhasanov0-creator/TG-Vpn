package dev.limonchik.tgvpn.core

import android.content.Context
import android.os.Build
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class AuthStep { Starting, Phone, Code, Password, Ready, Closed }
data class ChatItem(val id: Long, val title: String, val last: String)
data class MsgItem(val id: Long, val out: Boolean, val text: String, val date: Int)

sealed interface TgEvent {
    data class NewMessage(val chatId: Long, val msg: MsgItem) : TgEvent
    data class Replaced(val chatId: Long, val oldId: Long, val msg: MsgItem) : TgEvent
}

/** Лёгкий клиент Telegram на TDLib: без базы сообщений и файлов, весь трафик — через локальный SOCKS5 (Xray). */
class TgClient(private val ctx: Context, private val proxy: ProxyConfig) {
    private val _auth = MutableStateFlow(AuthStep.Starting)
    val auth = _auth.asStateFlow()
    private val _events = MutableSharedFlow<TgEvent>(extraBufferCapacity = 64)
    val events = _events.asSharedFlow()
    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val errors = _errors.asSharedFlow()

    private val client: Client = Client.create({ o -> onUpdate(o) }, null, null)

    private fun onUpdate(o: TdApi.Object) {
        when (o) {
            is TdApi.UpdateAuthorizationState -> onAuth(o.authorizationState)
            is TdApi.UpdateNewMessage -> _events.tryEmit(TgEvent.NewMessage(o.message.chatId, o.message.toItem()))
            is TdApi.UpdateMessageSendSucceeded ->
                _events.tryEmit(TgEvent.Replaced(o.message.chatId, o.oldMessageId, o.message.toItem()))
        }
    }

    private fun onAuth(s: TdApi.AuthorizationState) {
        when (s) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                client.send(TdApi.SetTdlibParameters().apply {
                    databaseDirectory = ctx.filesDir.resolve("td").absolutePath
                    useChatInfoDatabase = true
                    useMessageDatabase = false
                    useFileDatabase = false
                    useSecretChats = false
                    apiId = TgConfig.apiId
                    apiHash = TgConfig.apiHash
                    systemLanguageCode = Locale.getDefault().language
                    deviceModel = Build.MODEL
                    applicationVersion = "0.1.0"
                }) { report(it) }
                client.send(TdApi.AddProxy().apply {
                    server = "127.0.0.1"
                    port = proxy.socksPort
                    enable = true
                    type = TdApi.ProxyTypeSocks5(proxy.user, proxy.pass)
                }) { report(it) }
            }
            is TdApi.AuthorizationStateWaitPhoneNumber -> _auth.value = AuthStep.Phone
            is TdApi.AuthorizationStateWaitCode -> _auth.value = AuthStep.Code
            is TdApi.AuthorizationStateWaitPassword -> _auth.value = AuthStep.Password
            is TdApi.AuthorizationStateReady -> _auth.value = AuthStep.Ready
            is TdApi.AuthorizationStateClosed -> _auth.value = AuthStep.Closed
            else -> Unit
        }
    }

    private fun report(r: TdApi.Object) {
        if (r is TdApi.Error) _errors.tryEmit(r.message)
    }

    fun sendPhone(p: String) = client.send(TdApi.SetAuthenticationPhoneNumber().apply { phoneNumber = p }) { report(it) }
    fun sendCode(c: String) = client.send(TdApi.CheckAuthenticationCode().apply { code = c }) { report(it) }
    fun sendPassword(p: String) = client.send(TdApi.CheckAuthenticationPassword().apply { password = p }) { report(it) }
    fun close() { client.send(TdApi.Close()) { } }

    @Suppress("UNCHECKED_CAST")
    private suspend fun <T : TdApi.Object> call(f: TdApi.Function<*>): T = suspendCancellableCoroutine { c ->
        client.send(f) { r ->
            if (r is TdApi.Error) c.resumeWithException(RuntimeException(r.message)) else c.resume(r as T)
        }
    }

    suspend fun loadChats(limit: Int = 40): List<ChatItem> {
        runCatching { call<TdApi.Ok>(TdApi.LoadChats(TdApi.ChatListMain(), limit)) }
        val ids = call<TdApi.Chats>(TdApi.GetChats(TdApi.ChatListMain(), limit)).chatIds
        return ids.map { id ->
            val c = call<TdApi.Chat>(TdApi.GetChat(id))
            ChatItem(id, c.title, c.lastMessage?.preview() ?: "")
        }
    }

    suspend fun history(chatId: Long, limit: Int = 30): List<MsgItem> =
        call<TdApi.Messages>(TdApi.GetChatHistory(chatId, 0L, 0, limit, false))
            .messages.map { it.toItem() }.reversed()

    fun send(chatId: Long, text: String) {
        client.send(TdApi.SendMessage().apply {
            this.chatId = chatId
            inputMessageContent = TdApi.InputMessageText().apply {
                this.text = TdApi.FormattedText(text, emptyArray())
            }
        }) { report(it) }
    }
}

private fun TdApi.Message.preview(): String = (content as? TdApi.MessageText)?.text?.text ?: "[медиа]"
private fun TdApi.Message.toItem() = MsgItem(id, isOutgoing, preview(), date)

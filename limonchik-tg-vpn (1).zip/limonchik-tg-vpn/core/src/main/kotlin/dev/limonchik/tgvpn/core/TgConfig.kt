package dev.limonchik.tgvpn.core

/** Автор проекта. */
const val AUTHOR = "limonchik"

/** api_id / api_hash берутся из local.properties (см. README). Заполняется в MainActivity. */
object TgConfig {
    var apiId: Int = 0
    var apiHash: String = ""
}

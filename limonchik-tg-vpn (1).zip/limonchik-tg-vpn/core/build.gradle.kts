plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "dev.limonchik.tgvpn.core"
    compileSdk = 34
    defaultConfig { minSdk = 24 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // TDLib подтягивается автоматически (готовая сборка с JitPack); Xray (libv2ray.aar) лежит в ../libs
    api("com.github.fazilus:tdlib-android:1.8.61")
    compileOnly(fileTree("../libs") { include("*.aar") })
    api("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    api("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")
    api("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.core:core-ktx:1.13.1")
}
